#include "line_following_robot_4S.h"
/**
 * user-defined constants
 */


/**
 * init function
 */
void init(State* st) { 
    st->previous_mode = AUTO;
    st->mode = AUTO;
    st->forwardSpeed = 0.4f;
    st->highRotate = 0.3f;
    st->lfFarLeftVal = 0.0f;
    st->lfFarRightVal = 0.0f;
    st->lfMidLeftVal = 0.0f;
    st->lfMidRightVal = 0.0f;
    st->lowRotate = 0.0f;
    st->mediumRotate = 0.2f;
    st->servoLeftVal = 0.0f;
    st->servoRightVal = 0.0f;
}

/**
 * leave/enter functions
 */
void enter(Mode m, State* st) { 
    st->mode = m;
}
void leave(Mode m, State* st) { 
    st->previous_mode = m;
}

/**
 * triggers
 */

State* tick(State* st) {
    /*
	PLACE HERE the	
	custom code for the 
	control with 4 sensors
*/
    return st;
}




