import argparse
import csv
from matplotlib import pyplot as plt


parser = argparse.ArgumentParser(description='Process some integers.')
parser.add_argument('path', type=str, help='csv path in file sysetm')

args = parser.parse_args()

with open(args.path) as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
    titles = next(spamreader)
    x = []
    y = []
    for row in spamreader:
        x.append(float(row[6]))
        y.append(float(row[7]))
data = {titles[6]:x,titles[7]:y}
plt.figure()
plt.scatter(data[titles[6]],data[titles[7]])
plt.xlabel(titles[6])
plt.ylabel(titles[7])
plt.show()
